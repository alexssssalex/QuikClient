from setuptools import setup

setup(
    name='packagetemplate',
    description ='packagetemplate',
    version='0.0.0',
    author="Alexander Sokolov",
    author_email="sokolov_75@mail.ru",
    # urls = "",

    packages=['quikclient'],
    package_dir={'': 'src'},
)
