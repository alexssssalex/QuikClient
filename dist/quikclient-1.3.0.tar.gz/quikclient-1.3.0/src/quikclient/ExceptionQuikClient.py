class ExceptionQuikClient(Exception):
    pass