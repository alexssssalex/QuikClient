[Contributors](https://github.com/finsight/QUIKSharp/graphs/contributors)
===

* Oleg Andrushko &mdash; [@nubick](https://github.com/nubick)
* Victor Baybekov &mdash; [@buybackoff](https://github.com/buybackoff)
* [@Pr0phet1c](https://github.com/Pr0phet1c)
* [@SkyN](https://github.com/SkyN)
* [@sm00vik](https://github.com/sm00vik)
* [@spvik](https://github.com/spvik)
* [@stanislav-111](https://github.com/stanislav-111)

